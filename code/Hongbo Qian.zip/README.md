1. Part a, run `IMU_localization_EKF_prediction.py`
2. Part b, run `Landmark_Mapping_via_EKF_Update.py`
3. Part c, run `Visual_Inertial_SLAM.py`